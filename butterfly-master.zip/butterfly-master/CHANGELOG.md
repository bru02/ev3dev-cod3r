[3.2.5](https://github.com/paradoxxxzero/butterfly/compare/3.2.4...3.2.5)
=====

* Fix #155 again (PR #179)


[3.2.4](https://github.com/paradoxxxzero/butterfly/compare/3.2.3...3.2.4)
=====

* Fix up --uri-root-path so behaves as one would expect for this. Fix #155 (PR #173 thanks @GrahamDumpleton)
* Fix websocket keepalive. Fix #167 (PR #172 thanks @fzumstein)

[3.2.3](https://github.com/paradoxxxzero/butterfly/compare/3.2.2...3.2.3)
=====

* Complete support for IME & CJK rendering (#168 thanks @PeterCxy)

3.2.2
=====

* Fix unescaping entities when linkifying

3.2.1
=====

* Issue correct X.509 v3 certificates (you will need to re-generate your certs)

3.1.5
=====

* Fix new option in older tornado version. (#146 thanks @warpkwd)

3.1.4
=====

* Add --i-hereby-declare-i-dont-want-any-security-whatsoever option (#143)

3.1.3
=====

* Fix lsof parsing crash on python 2

3.1.0
=====

* Start a changelog
